﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

class Program
{
    static async Task Main(string[] args)
    {
        Console.WriteLine("Simulación de la línea de producción iniciada.\n");

        
        int cantidadDeProductos = 5;
        var tareas = new List<Task>();

        for (int i = 1; i <= cantidadDeProductos; i++)
        {
            int productoId = i;
            tareas.Add(ProcesarProductoAsync(productoId));
        }

       
        await Task.WhenAll(tareas);

        Console.WriteLine("\nTodas las líneas de producción han finalizado.");
    }

    static async Task ProcesarProductoAsync(int productoId)
    {
        var stopwatch = Stopwatch.StartNew();

        try
        {
            Console.WriteLine($"Producto {productoId}: Inicio del proceso.\n");

            
            await Task.Run(() => Fabricacion(productoId));
            Console.WriteLine($"Producto {productoId}: Fabricación completada en {stopwatch.ElapsedMilliseconds} ms.\n");

            await Task.Run(() => Empaquetado(productoId));
            Console.WriteLine($"Producto {productoId}: Empaquetado completado en {stopwatch.ElapsedMilliseconds} ms.\n");

            
            await Task.Run(() => Envio(productoId));
            Console.WriteLine($"Producto {productoId}: Envío completado en {stopwatch.ElapsedMilliseconds} ms.\n");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Producto {productoId}: Error - {ex.Message}\n");
        }
        finally
        {
            stopwatch.Stop();
            Console.WriteLine($"Producto {productoId}: Proceso finalizado. Tiempo total: {stopwatch.ElapsedMilliseconds} ms.\n");
        }
    }

    static void Fabricacion(int productoId)
    {
        Console.WriteLine($"Producto {productoId}: Fabricación iniciada.");
        Task.Delay(new Random().Next(500, 1000)).Wait();
    }

    static void Empaquetado(int productoId)
    {
        Console.WriteLine($"Producto {productoId}: Empaquetado iniciado.");
        Task.Delay(new Random().Next(300, 700)).Wait(); 
    }

    static void Envio(int productoId)
    {
        Console.WriteLine($"Producto {productoId}: Envío iniciado.");
        Task.Delay(new Random().Next(400, 800)).Wait(); 
    }
}
 