﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

class DefensaDeLaFortaleza
{
    static int fortalezaVida = 100;
    static object lockObject = new object();

    static async Task Main(string[] args)
    {
        Console.WriteLine("¡Defensa de la Fortaleza ha comenzado!");

        // Inicia las oleadas de enemigos
        var oleadas = new List<Task>
        {
            SimularOleada(1),
            SimularOleada(2),
            SimularOleada(3)
        };

        await Task.WhenAll(oleadas);

        Console.WriteLine(fortalezaVida > 0
            ? "¡Has defendido la fortaleza con éxito!"
            : "¡La fortaleza ha caído!");
    }

    static async Task SimularOleada(int numeroOleada)
    {
        Console.WriteLine($"Oleada {numeroOleada} está llegando...");
        var enemigos = new List<Task>();

        // Generar enemigos aleatorios en la oleada
        for (int i = 0; i < 5; i++)
        {
            int enemigoId = i + 1;
            enemigos.Add(SimularEnemigo(enemigoId, numeroOleada));
        }

        // Ejecutar las tareas de los enemigos
        await Task.WhenAll(enemigos);
        Console.WriteLine($"¡Oleada {numeroOleada} completada!");
    }

    static async Task SimularEnemigo(int enemigoId, int oleada)
    {
        Console.WriteLine($"Enemigo {enemigoId} de la Oleada {oleada} está atacando...");

        // Simular ataque con un retraso aleatorio
        int retraso = new Random().Next(1000, 5000);
        await Task.Delay(retraso);

        // Simular daño a la fortaleza
        lock (lockObject)
        {
            if (fortalezaVida > 0)
            {
                int dano = new Random().Next(5, 20);
                fortalezaVida -= dano;
                Console.WriteLine($"Enemigo {enemigoId} hizo {dano} de daño. Vida restante de la fortaleza: {fortalezaVida}");
            }
        }

        if (fortalezaVida <= 0)
        {
            Console.WriteLine("¡La fortaleza ha caído!");
            Environment.Exit(0); // Finalizar el juego
        }
    }
}
